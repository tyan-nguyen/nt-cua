 <section class="subscribe">
      <div class="container">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-8">
            <div class="subscribe-content padding-medium">
              <div class="subscribe-header">
                <h2 class="display-4">Nhận tư vấn miễn phí</h2>
              </div>
              <form id="form">
                <input type="text" name="email" placeholder="Điền Số điện thoại/Email của bạn" class="w-100 bg-light border-0 ps-5 fst-italic">
                <button class="btn btn-full btn-black text-uppercase">Đăng ký</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>