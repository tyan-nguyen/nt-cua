<div class="col-lg-4 col-md-6 col-sm-12 mb-5">
            <div class="card-item">
              <div class="card border-0 bg-transparent">
                <div class="card-image">
                  <img src="<?= Yii::getAlias('@web')  ?>/images/post-item1.jpg" alt="" class="post-image img-fluid">
                </div>
              </div>
              <div class="card-body p-0 mt-4">
                <h3 class="card-title text-uppercase">
                  <a href="single-post.html">Báo giá nhôm Xingfa tháng 8/2023</a>
                </h3>
                <p>DNTN Nguyễn Trình kính gửi Quý Khách hàng bảng báo giá cửa nhôm Xingfa chính hãng tháng 8/2023.</p>
                <a href="single-post.html" class="btn btn-normal text-uppercase p-0"><em>Xem tiếp</em></a>
              </div>
            </div>
          </div>