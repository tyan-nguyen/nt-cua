<div class="swiper-slide">
  <div class="product-card image-zoom-effect link-effect d-flex flex-wrap">
    <div class="image-holder">
      <img src="<?= Yii::getAlias('@web')  ?>/img/product-item5.png" alt="product-item" class="product-image img-fluid">
    </div>
    <div class="cart-concern">
      <h3 class="card-title text-uppercase pt-3 text-primary">
        <a href="single-product.html" class="text-primary">Cửa thủy lực 2 cánh - Lam sáng</a>
      </h3>
      <div class="cart-info">
        <a class="pseudo-text-effect" href="#" data-after="ĐẶT HÀNG">
          <span>3,000,000 VNĐ/<sup>2</sup></span>
        </a>
      </div>
    </div>
  </div>
</div>