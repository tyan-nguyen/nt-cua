<div class="swiper-slide">
  <div class="product-card image-zoom-effect link-effect d-flex flex-wrap">
    <div class="image-holder">
      <img src="<?= Yii::getAlias('@web')  ?>/img/product-item2.png" alt="product-item" class="product-image img-fluid">
    </div>
    <div class="cart-concern">
      <h3 class="card-title text-uppercase pt-3 text-primary">
        <a href="single-product.html" class="text-primary">Cửa đi 2 cánh</a>
      </h3>
      <div class="cart-info">
        <a class="pseudo-text-effect" href="#" data-after="ĐẶT HÀNG">
          <span>2,000,00 VNĐ/m<sup>2</sup></span>
        </a>
      </div>
    </div>
  </div>
</div>