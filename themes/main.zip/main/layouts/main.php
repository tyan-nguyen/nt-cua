
<?= $this->render('head') ?>

<?= $this->render('header') ?>

<?= $this->render('slides') ?>

<?= $this->render('services') ?>

<?php // $this->render('about') ?>

<?= $this->render('product') ?>

<?php //$this->render('quote') ?>

<?= $this->render('collection') ?>

<?= $this->render('subscribe') ?>

<?php //$this->render('trending') ?>

<?= $this->render('article') ?>

<?= $this->render('brand') ?>

<?= $this->render('end') ?>