 <section id="brand-collection" class="padding-small border-top border-bottom overflow-hidden margin-large mb-0">
      <div class="container">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <a href="#"><img src="<?= Yii::getAlias('@web')  ?>/img/nhom-xingfa.png" alt="brand"></a>
            <a href="#"><img src="<?= Yii::getAlias('@web')  ?>/img/logo.png" alt="brand"></a>
            <a href="#"><img src="<?= Yii::getAlias('@web')  ?>/img/nhom-xingfa.png" alt="brand"></a>
            <a href="#"><img src="<?= Yii::getAlias('@web')  ?>/img/logo.png" alt="brand"></a>
        </div>
      </div>
    </section>